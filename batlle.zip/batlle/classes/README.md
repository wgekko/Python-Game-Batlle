## este es un trabajo con el tuturial de udemy 
## con el profeser  Joseph Delgadillo y Nick Germaine
## se desarrolla un juego de consola básico con pocos elmentos de imagenes
## en juego consiste en una batalla entre 3 jugadores y 3 enemigos 
## que tienen hechizos magicos y curas alternativas
## como asi tambien herramientas para el ataque 
## desarollado por Walter Gomez @copyright enero 2022